# XenoPT
Garnet two-pyroxene thermobarometry package.

https://pypi.org/project/xenopt/
